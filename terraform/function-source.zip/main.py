import json
import logging
import os
import traceback
from datetime import datetime

from google.api_core import retry
from google.cloud import bigquery
from google.cloud import storage
import pytz

from dotenv import load_dotenv
import os

load_dotenv()

PROJECT_ID = os.getenv('PROJECT_ID')
BQ_DATASET = os.getenv('BQ_DATASET')
BQ_TABLE = os.getenv('BQ_TABLE')

CS = storage.Client()
BQ = bigquery.Client()

# Triggered by a change in a storage bucket
def streaming(cloud_event, context):
    '''This function is executed whenever a file is added to Cloud Storage'''
    bucket_name = cloud_event['bucket']
    file_name = cloud_event['name']

    try:
        # Insert the file's content into BigQuery with auto-detection of schema
        _load_json_into_bigquery(bucket_name, file_name)
        _handle_success(file_name)
    except Exception:
        _handle_error(file_name)


def _load_json_into_bigquery(bucket_name, file_name):
    '''Load the JSON file from GCS into BigQuery with schema auto-detection'''
    bucket = CS.get_bucket(bucket_name)
    blob = bucket.blob(file_name)
    uri = f'gs://{bucket_name}/{file_name}'

    # Set up the BigQuery table reference
    table_ref = BQ.dataset(BQ_DATASET).table(BQ_TABLE)

    # Configure the load job with auto schema detection
    job_config = bigquery.LoadJobConfig(
        source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
        autodetect=True  # Enable schema auto-detection
    )

    # Start the load job from the GCS URI
    load_job = BQ.load_table_from_uri(
        uri, table_ref, job_config=job_config
    )

    # Wait for the job to complete
    load_job.result()

    # Check if the job had any errors
    if load_job.errors:
        raise BigQueryError(load_job.errors)


def _handle_success(file_name):
    '''Log success message after successful BigQuery insertion'''
    message = f"File '{file_name}' successfully loaded into BigQuery."
    logging.info(message)


def _handle_error(file_name):
    '''Log error message if something goes wrong during streaming'''
    message = f"Error loading file '{file_name}' into BigQuery. Cause: {traceback.format_exc()}"
    logging.error(message)


def _now():
    '''Return the current UTC time as a string'''
    return datetime.utcnow().replace(tzinfo=pytz.utc).strftime('%Y-%m-%d %H:%M:%S %Z')


class BigQueryError(Exception):
    '''Custom Exception raised for BigQuery errors'''

    def __init__(self, errors):
        super().__init__(self._format(errors))
        self.errors = errors

    def _format(self, errors):
        '''Format the error messages'''
        err = []
        for error in errors:
            err.extend(error['errors'])
        return json.dumps(err)